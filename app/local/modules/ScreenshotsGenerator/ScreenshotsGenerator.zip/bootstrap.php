<?php

/**
 * Class ScreenshotsGenerator_Bootstrap
 */
class ScreenshotsGenerator_Bootstrap {

    public static function init($bootstrap) {}

}